import React, { createContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { dummyProducts } from "../assets/Data";
import { toast } from "react-toastify";

export const ShopContext = createContext();

const ShopContextProvider = ({ children }) => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [showUserLogin, setShowUserLogin] = useState("");
  const [cartItems, setCartItems] = useState({});
  const [orders, setOrders] = useState([]);

  // ✅ Load from localStorage on mount
  useEffect(() => {
    setProducts(dummyProducts);

    const savedCart = JSON.parse(localStorage.getItem("cartItems")) || {};
    setCartItems(savedCart);

    const savedOrders = JSON.parse(localStorage.getItem("orders")) || [];
    setOrders(savedOrders);

    const savedUser = JSON.parse(localStorage.getItem("user")) || null;
    setUser(savedUser);
  }, []);

  // ✅ Save to localStorage whenever cartItems changes
  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  // ✅ Save to localStorage whenever orders changes
  useEffect(() => {
    localStorage.setItem("orders", JSON.stringify(orders));
  }, [orders]);

  // ✅ Save user to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
    } else {
      localStorage.removeItem("user");
    }
  }, [user]);

  const addToCart = async (itemId, size) => {
    if (!size) {
      toast.error("Please select a size first", {
        position: "top-right",
        autoClose: 3000,
        theme: "dark",
      });
      return;
    }

    const key = `${itemId}_${size}`;

    setCartItems((prev) => ({
      ...prev,
      [key]: prev[key] ? prev[key] + 1 : 1,
    }));

    toast.success("Item added to Cart", {
      position: "top-right",
      autoClose: 3000,
      theme: "dark",
    });
  };

  const getCartItemCount = () => {
    return Object.values(cartItems).reduce((total, qty) => total + qty, 0);
  };

  const count = getCartItemCount();

  const placeorder = (orderData) => {
    if (!user) {
      toast.error("Please login before placing an order", {
        position: "top-right",
        autoClose: 3000,
        theme: "dark",
      });
      setShowUserLogin(true); // open login modal
      return;
    }

    const newOrder = {
      id: Date.now().toString(36),
      items: orderData.items,
      amount: orderData.amount,
      method: orderData.method,
      status: "Order Placed",
      paymentStatus: "Pending",
      date: new Date().toDateString(),
      userId: user?.email || user?.id || "guest",
    };

    setOrders((prev) => [...prev, newOrder]);

    // ✅ clear cart after placing order
    setCartItems({});
    localStorage.removeItem("cartItems");

    toast.success("Order placed successfully", {
      position: "top-right",
      autoClose: 3000,
      theme: "dark",
    });

    navigate("/my-orders");
  };

  const value = {
    user,
    setUser,
    navigate,
    products,
    search,
    setSearch,
    showUserLogin,
    setShowUserLogin,
    addToCart,
    cartItems,
    setCartItems,
    getCartItemCount,
    orders,
    setOrders,
    placeorder,
    count,
  };

  return (
    <ShopContext.Provider value={value}>{children}</ShopContext.Provider>
  );
};

export default ShopContextProvider;
