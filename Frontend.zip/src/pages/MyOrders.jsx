import React, { useContext } from "react";
import { ShopContext } from "../context/ShopContext";

const MyOrders = () => {
  const { orders, products } = useContext(ShopContext);

  return (
    <section className="px-20 py-30 bg-gray-100">
      <h1 className="text-3xl font-bold mb-2">
        My Orders <span className="text-gray-500 underline">List</span>
      </h1>
      <p className="text-gray-500 mb-6">
        Explore your past purchases and track the status of your orders.
      </p>

      {!orders || orders.length === 0 ? (
        <p className="text-gray-600">No orders yet.</p>
      ) : (
        orders.map((order) => (
          <div key={order.id} className="bg-white p-6 rounded shadow-md mb-6">
            {/* Items inside this order */}
            {order.items.map((item, idx) => {
              const product = products.find((p) => p._id === item.productId) || {};
              return (
                <div
                  key={idx}
                  className="flex items-center gap-6 border-b pb-4 mb-4"
                >
                  <img
                    src={product.image || "/tshirt.png"}
                    alt={product.name || "Product"}
                    className="w-20 h-20 object-cover border"
                  />
                  <div>
                    <h2 className="font-semibold">{product.name || item.productId}</h2>
                    <p>
                      Price: ${product.price || "N/A"} | Quantity: {item.qty} | Size:{" "}
                      {item.size}
                    </p>
                  </div>
                </div>
              );
            })}

            {/* Order details */}
            <div className="text-sm text-gray-600">
              <p>
                <strong>OrderId:</strong> {order.id}
              </p>
              <p>
                <strong>Payment Status:</strong> {order.paymentStatus} |{" "}
                <strong>Method:</strong> {order.method}
              </p>
              <p>
                <strong>Date:</strong> {order.date} |{" "}
                <strong>Amount:</strong> ${order.amount}
              </p>
            </div>

            {/* Footer actions */}
            <div className="mt-3 flex justify-between items-center">
              <p className="text-green-600 font-medium">
                Status: {order.status}
              </p>
              <button className="bg-gray-600 text-white px-3 py-1 rounded text-sm">
                Track Order
              </button>
            </div>
          </div>
        ))
      )}
    </section>
  );
};

export default MyOrders;
