import React from "react";
import { FaLocationDot, FaEnvelope, FaPhone, FaHeadphones } from "react-icons/fa6";

const Contact = () => {
  return (
    <section className="py-30 px-3 bg-gradient-to-r from-gray-200 to-gray-200">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-10">
        <div className="flex-1">
          <h2 className="text-3xl font-bold mb-2">
            Get <span className="text-gray-500 underline font-semibold">in Touch</span>
          </h2>
          <p className="text-gray-500 mb-8">
            Have questions or need help? Send us a message, and we'll get<br/> back to you as soon as possible.
          </p>

          <form className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4">
              <input
                type="text"
                placeholder="Enter your name"
                className="flex-1 border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-black"
              />
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 border border-gray-300 px-4 py-3 rounded focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>
            <textarea
              rows="4"
              placeholder="Write your message here"
              className="border border-gray-300 px-4 py-3 rounded focus:outline-none focus:ring-2 focus:ring-black"
            ></textarea>
            <button
              type="submit"
              className="bg-black text-white px-6 py-3 rounded hover:bg-gray-800 transition-all duration-300 w-max cursor-pointer"
            >
              Send Message
            </button>
          </form>
        </div>

        <div className="flex-1">
          <h2 className="text-3xl font-bold mb-2">
            Contact <span className="text-gray-500 underline">Details</span>
          </h2>
          <p className="text-gray-500 mb-8">
            We are always here to assist you! Feel free to reach out to us<br/> through any of the following methods.
          </p>
          <div className="flex flex-col gap-6">
            <div className="flex items-start gap-4">
              <FaLocationDot className="text-black mt-1" />
              <div>
                <h5 className="font-semibold text-gray-700 mb-1">Location:</h5>
                <p className="text-gray-500 text-sm">
                  123 Shopprr Street, Clothing City, FC 12345
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <FaEnvelope className="text-black mt-1" />
              <div>
                <h5 className="font-semibold text-gray-700 mb-1">Email:</h5>
                <p className="text-gray-500 text-sm">info@shopprr.com</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <FaPhone className="text-black mt-1" />
              <div>
                <h5 className="font-semibold text-gray-700 mb-1">Phone:</h5>
                <p className="text-gray-500 text-sm">+1 (800) 123-4567</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <FaHeadphones className="text-black mt-1" />
              <div>
                <h5 className="font-semibold text-gray-700 mb-1">Support:</h5>
                <p className="text-gray-500 text-sm">24/7 Support is open</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
