import React from 'react'
import { Link } from 'react-router-dom'
import heroImg from '../assets/heroImg.jpg'

const Hero = () => {
  return (
    <section
      className="w-full bg-gradient-to-r from-gray-200 to-gray-300 py-20 lg:py-45 ">
      <div
        className="
          max-w-7xl
          mx-auto
          flex flex-col-reverse lg:flex-row
          items-center
          gap-12
          px-6"
      >
        <div className="flex-1">
          <h3 className="text-gray-500 font-paci text-xl mb-2">
            Fresh Fits for Frosty Days
          </h3>

          <h2 className="text-black uppercase text-3xl lg:text-5xl font-extrabold tracking-wide mb-4">
            Get More for Less – 40% Off!
          </h2>

          <h1 className="text-black font-black text-4xl lg:text-6xl leading-tight mb-6">
            on Coats & Jackets
          </h1>

          <div className="flex items-center gap-3 mb-8">
            <h3 className="text-lg font-medium text-gray-700">
              Starting at
            </h3>
            <span
              className="
                bg-white px-3 py-1
                rotate-[-2deg]
                font-bold
                text-black
                text-2xl
                shadow-lg
              "
            >
              <span className="text-black">₹</span>
              99.<span className="text-base font-normal">99</span>
            </span>
          </div>

          <Link
            to="/collection"
            className="
              inline-block
              bg-black text-white
              px-8 py-4
              rounded-full
              text-lg font-bold
              shadow-lg
              hover:bg-gray-800
              transition-all duration-300
            "
          >
            Shop Now
          </Link>
        </div>

        <div className="flex-1 relative w-full max-w-[500px]">
          <img
            src={heroImg}
            alt="Hero"
            className="relative w-full rounded-lg shadow-xl object-cover"
          />
        </div>
      </div>
    </section>
  )
}

export default Hero
