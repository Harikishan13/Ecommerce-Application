import React from 'react';
import { useNavigate } from 'react-router-dom';
import { dummyProducts } from '../assets/Data';

const RelatedProducts = ({ category }) => {
  const navigate = useNavigate();

  // Filter products by category
  const related = dummyProducts.filter(
    (product) => product.category === category
  );

  return (
    <section className="px-3 py-16 bg-gradient-to-r from-gray-200 to-gray-200">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-2">
          Related <span className="text-gray-500 underline">Products</span>
        </h2>
        <p className="text-black/50 mb-6">
          Explore our collection of products under the category:{" "}
          <span className="text-black font-semibold">{category}</span>
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {related.map((product) => (
              <div
                key={product._id}
                className="h-[300px] p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 flex flex-col bg-white"
              >
                <div
                  onClick={() =>
                    navigate(`/collection/${product.category}/${product._id}`)
                  }
                  className="flex items-center justify-center bg-gray-100 overflow-hidden h-[180px] rounded cursor-pointer"
                >
                  <img
                    src={product.image[0]}
                    alt={product.name}
                    className="object-contain h-full w-auto"
                  />
                </div>

                <div className="flex-grow flex flex-col justify-between mt-2">
                  <div>
                    <h4 className="font-bold text-[15px] uppercase line-clamp-1">
                      {product.name}
                    </h4>
                    <p className="text-black/50 text-sm line-clamp-1">
                      {product.description}
                    </p>
                  </div>

                  <div className="flex justify-between pt-2 text-sm">
                    <p className="text-gray-600">{product.category}</p>
                    <button className="border border-gray-300 py-1 px-3 text-xs rounded hover:bg-gray-100 transition">
                      Add to Cart | ₹{product.offerPrice}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
      </div>
    </section>
  );
};

export default RelatedProducts;
