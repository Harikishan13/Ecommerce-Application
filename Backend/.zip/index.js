const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const Stripe = require("stripe"); 
require("dotenv").config();

const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

app.use(express.json());
app.use(cors({
  origin: "http://localhost:5173", // your React app
  methods: ["GET", "POST"],
  credentials: true
}));



const UserSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String, 
});

const User = mongoose.model("User", UserSchema);


mongoose
  .connect(process.env.MONGO_URL)
  .then(() => console.log("✅ MongoDB connected"))
  .catch((err) => console.log("❌ MongoDB error:", err));

const SECRET_KEY = process.env.JWT_SECRET;

app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });
    await User.create({ name, email, password });
    res.json({ message: "Registered successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "No registered account" });

    if (user.password !== password) {
      return res.status(401).json({ message: "Password incorrect" });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email },
      SECRET_KEY,
      { expiresIn: "1h" }
    );

    res.json({ message: "success", token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------- STRIPE PAYMENT ----------------
app.post("/create-checkout-session", async (req, res) => {
  try {
    console.log("📩 Request body from frontend:", req.body);

    const { items } = req.body;

    if (!items || items.length === 0) {
      console.error("❌ No items received");
      return res.status(400).json({ error: "No items provided" });
    }

    const line_items = items.map((item) => ({
      price_data: {
        currency: "usd",
        product_data: {
          name: item.name,
        },
        unit_amount: Math.round(item.price * 100), // cents
      },
      quantity: item.quantity,
    }));

    console.log("🛒 Stripe Line Items:", line_items);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items,
      mode: "payment",
      success_url: "http://localhost:5173/success",
      cancel_url: "http://localhost:5173/cancel",
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error("❌ Stripe Checkout Error:", err.message);
    res.status(500).json({ error: err.message });
  }
});


app.listen(8000, () => {
  console.log("🚀 Server running ");
});
